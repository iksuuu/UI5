sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("sap.ui5.walkthrough.pythonui5.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  